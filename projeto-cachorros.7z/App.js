
import  React, { useState } from 'react';
import { Button, View, StyleSheet, Text, Image} from 'react-native';
import {createDrawerNavigator} from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import { AntDesign } from '@expo/vector-icons'; 
import Login from './src/components/login/login';
import Menu from './src/components/MenuTabs/menu';

function HomeScreen({ navigation }) {
  return (
    <View style={{}}>
      <View style={{alignItems: 'center', }}>
      <Text>Oi amigues</Text>
    </View>
    </View>
  );
}
  
function CachorrosScreen({ navigation }) {  
  return (
<View style={{}}>
    <View style={{alignItems: 'center', }}>
    <Text>Cachorros Cadastrados</Text>
    </View>
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center',}}>
      <Image source={require('./Imagens/cachorro1.png')} style={{width: 300, height: 300, borderColor: "red", borderWidth: 5,}} />
      <Image source={require('./Imagens/cachorro2.jpg')} style={{width: 300, height: 300, borderColor: "red", borderWidth: 5,}} />

    </View>
  </View>
  );
}

function LoginScreen({ navigation }) {
    const [user,setUser]= useState(null);
    if(!user){
      return <Login changeStatus={(user)=> setUser(user)}/>
      
    }
    return <Menu/>
  }
  
const Drawer = createDrawerNavigator();

export default function App() {
    return (

    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home"
        screenOptions={{
            drawerStyle:{
            backgroundColor:"white",
            width:240,
        },
        }}>

      <Drawer.Screen 
        options={{
            drawerIcon: config => <AntDesign name="home" size={24} color="black" />}}
        name="Home" component={HomeScreen} />

        <Drawer.Screen 
        options={{
            drawerIcon: config => <AntDesign name="login" size={24} color="black" />}}
        name="Login" component={LoginScreen} />
        
        <Drawer.Screen
        options={{
            drawerIcon: config=> <AntDesign name="inbox" size={24} color="black" />}}
        name="Cachorros" component={CachorrosScreen} />
            
      </Drawer.Navigator>
    </NavigationContainer>
    );
}