# CRUD Firebase
CRUD with firebase and react native expo ⚛️

### Check out the video tutorial [here](https://www.youtube.com/watch?v=2lkfcEsTkg0)
![Frame 70](https://user-images.githubusercontent.com/43630417/167732099-642670f3-277c-4c2b-b043-d3f6dfa9cbde.png)
