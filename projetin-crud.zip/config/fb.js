import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import Constants from 'expo-constants';

// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyD2yE5YzYxmm1wwz6Gdooyqby7jOm3GRhw",
  authDomain: "trabalhofinal-52cd8.firebaseapp.com",
  projectId: "trabalhofinal-52cd8",
  storageBucket: "trabalhofinal-52cd8.appspot.com",
  messagingSenderId: "221045052029",
  appId: "1:221045052029:web:d9be89b6b77c80034a1714"
};

// initialize firebase
initializeApp(firebaseConfig);
export const database = getFirestore();